
rm(list=ls())
options(stringsAsFactors = FALSE)
setwd("/ix/kfan/Ruyu/harmonization/All_Cohorts/")

library(dplyr)
library(data.table)

################################################################################
### Process each cohort to get case/control lists
################################################################################

# read in data from Lynda (old Ver.)
gwas_all_retrieved <- openxlsx::read.xlsx("./V_DataRequest_Ruyu_GWAS_Info_2023_12_20.xlsx")
head(gwas_all_retrieved)

# read in data from Lynda (most up-to-date Ver.)
gwas_all <- openxlsx::read.xlsx("./V_DataRequest_Cheema_Manuscript_Plus_BSamples_2024_04_28.xlsx")

# read in filtered .fam file

fam <- fread("./pseudoGWAS_input/All_Cohorts_allChr_exSamples.fam")
sample <- unique(sub(".*:", "", fam$V1))
# 10603
# sample.dups <- sample[duplicated(sample)]

sample <- stringr::str_sub(sample, 1, nchar(sample)/2)
write.table(as.data.frame(sample), "./GWAS_Harmonization_ScanName_final.txt", col.names = FALSE, row.names = FALSE, quote = FALSE)

# subset based on list of samples
setdiff(sample, gwas_all_retrieved$Scan_Name %in% sample)

dd <- gwas_all_retrieved[gwas_all_retrieved$Scan_Name %in% sample, c("Scan_Name", "Case_Control", "Case_Control_DB", "Flag_Case_Control")]
d <- dd %>% distinct()
d$case_control_recode <- ifelse(d$Case_Control < 0, NA, 
                                ifelse(d$Case_Control == "Control", "Control", "Case"))
table(d$case_control_recode)
sum(is.na(d$case_control_recode))

write.table(as.data.frame(c(setdiff(sample, gwas_all_retrieved$Scan_Name), d[is.na(d$case_control_recode),]$Scan_Name)), 
            "./GWAS_Harmonization_ScanName_final_noCaseControlStatus.txt", col.names = FALSE, row.names = FALSE, quote = FALSE)



################################################################################
### Combine the case/control lists of each cohort
################################################################################

case_pattern <- "_ca"
control_pattern <- "_co"

cases <- ls()[grep(case_pattern, ls())]
controls <- ls()[grep(control_pattern, ls())]

case_list <- list()
control_list <- list()
for (num in 1:length(cases)){
  case_list[[num]] <- get(cases[num])
  control_list[[num]] <- get(controls[num])
}

case_d <- do.call(rbind, case_list)
# dim(case_d)
# [1] 2156    4

control_d <- do.call(rbind, control_list)
# dim(control_d)
# [1] 3998    4

all_d <- rbind(case_d, control_d)
# all_d$row_num <- 1:nrow(all_d)
# all_d$Scan_Name[duplicated(all_d$Scan_Name)]
# all_d[all_d$Scan_Name %in% c("6209254","a1723"),]
# all_d <- all_d[!(all_d$row_num %in% c(5248, 5253)),]
dim(all_d)
# [1] 6152   4
all_d[all_d$cohort == "GWAS1", ]$cohort <- "gwas1"
table(all_d$cohort)
#  gem gwas1 gwas2 gwas3 gwas5 
# 2502  2282   618   515   235 

################################################################################
### Process each cohort to age/sex/race information for pseudoGWAS
################################################################################

gwas_pheno <- unique(merge(all_d, gwas_all_retrieved[,c("AlzID_DB", "Scan_Name","Sex","Race","Sex_DB","Flag_Sex","Race_DB","Flag_Race","APOE_DB")], 
                    by = "Scan_Name", all.x = TRUE))
# note: duplicates are caused by missing value in APOE - after manually check, there is no discrepancies in APOE and APOE_DB of those individuals, thus remove "APOE" and "APOE_flag" when merge the dataframe
# View(as.data.frame(gwas_pheno[gwas_pheno$Scan_Name %in% gwas_pheno$Scan_Name[duplicated(gwas_pheno$Scan_Name)], ]))

# sex
gwas_pheno$sex_recode <- ifelse(!is.na(gwas_pheno$Flag_Sex), gwas_pheno$Sex_DB, gwas_pheno$Sex)
# sum(is.na(gwas_pheno$sex_recode)) # 0 

# race
gwas_pheno$race_recode <- ifelse(!is.na(gwas_pheno$Flag_Race), gwas_pheno$Race_DB, gwas_pheno$Race)
# sum(is.na(gwas_pheno$race_recode))
# gwas_pheno[is.na(gwas_pheno$race_recode),c("Scan_Name", "Race_DB")]
# four samples have Race_DB (Race info is missing), but not marked in the Race_Flag column, manually assign 
gwas_pheno[gwas_pheno$Scan_Name == "cPib148",]$race_recode <- "W"
gwas_pheno[gwas_pheno$Scan_Name == "cPib181",]$race_recode <- "W"
gwas_pheno[gwas_pheno$Scan_Name == "cPib190",]$race_recode <- "W"
gwas_pheno[gwas_pheno$Scan_Name == "cPib231",]$race_recode <- "B"
# sum(is.na(gwas_pheno$race_recode)) # double-check # 0 

# APOE
gwas_pheno$apoe_recode <- gwas_pheno$APOE_DB
# sum(is.na(gwas_pheno$apoe_recode))
# table(gwas_pheno[is.na(gwas_pheno$apoe_recode),]$cohort)
# gwas1 gwas3 
#    79     5 

all_pheno_d <- gwas_pheno[,c("Scan_Name", "V1", "case_control_recode", "cohort", "AlzID_DB", "sex_recode", "race_recode", "apoe_recode")]
dim(all_pheno_d)
# 6152    8
# table(all_pheno_d$race_recode)
all_pheno_d <- all_pheno_d[!(all_pheno_d$race_recode %in% "-4"), ]
dim(all_pheno_d)
# 6151    8

# case-control 
table(all_pheno_d$case_control_recode)
#  Case Control 
#  2156    3995 

case_d <- all_pheno_d[all_pheno_d$case_control_recode == "Case", ]
# dim(case_d)
table(case_d$race_recode)

control_d <- all_pheno_d[all_pheno_d$case_control_recode == "Control", ]
# dim(control_d)
table(control_d$race_recode)

# generate file for pseudoGWAS
# table(control_d$cohort)
# PLINK assumes that controls are coded as 1 and cases are coded as 2 by default
control_d$GWAS1_2 <- ifelse(control_d$cohort == "gwas1", 2, 
                            ifelse(control_d$cohort == "gwas2", 1, NA))
control_d$GWAS1_3 <- ifelse(control_d$cohort == "gwas1", 2, 
                            ifelse(control_d$cohort == "gwas3", 1, NA))
control_d$GWAS1_5 <- ifelse(control_d$cohort == "gwas1", 2, 
                            ifelse(control_d$cohort == "gwas5", 1, NA))
control_d$GWAS1_GEM <- ifelse(control_d$cohort == "gwas1", 2, 
                              ifelse(control_d$cohort == "gem", 1, NA))
control_d$GWAS2_3 <- ifelse(control_d$cohort == "gwas2", 2, 
                            ifelse(control_d$cohort == "gwas3", 1, NA))
control_d$GWAS2_5 <- ifelse(control_d$cohort == "gwas2", 2, 
                            ifelse(control_d$cohort == "gwas5", 1, NA))
control_d$GWAS2_GEM <- ifelse(control_d$cohort == "gwas2", 2, 
                              ifelse(control_d$cohort == "gem", 1, NA))
control_d$GWAS3_5 <- ifelse(control_d$cohort == "gwas3", 2, 
                            ifelse(control_d$cohort == "gwas5", 1, NA))
control_d$GWAS3_GEM <- ifelse(control_d$cohort == "gwas3", 2, 
                              ifelse(control_d$cohort == "gem", 1, NA))
control_d$GWAS5_GEM <- ifelse(control_d$cohort == "gwas5", 2, 
                              ifelse(control_d$cohort == "gem", 1, NA))

################################################################################
### Write output
################################################################################

write.table(all_pheno_d[,c("Scan_Name", "V1")], "All_Cohorts_ScanName.txt", sep = "\t", col.names = TRUE, row.names = FALSE, quote = FALSE)
write.table(all_pheno_d[,"V1"], "All_Cohorts_ScanName_vcftools_keepList.txt", sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)

write.table(all_pheno_d[all_pheno_d$case_control_recode == "Case", c("Scan_Name", "V1")], "All_Cohorts_Case_ScanName.txt", sep = "\t", col.names = TRUE, row.names = FALSE, quote = FALSE)
write.table(all_pheno_d[all_pheno_d$case_control_recode == "Case", "V1"], "All_Cohorts_Case_ScanName_vcftools_keepList.txt", sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)
write.table(all_pheno_d[all_pheno_d$case_control_recode == "Control", c("Scan_Name", "V1")], "All_Cohorts_Control_ScanName.txt", sep = "\t", col.names = TRUE, row.names = FALSE, quote = FALSE)
write.table(all_pheno_d[all_pheno_d$case_control_recode == "Control", "V1"], "All_Cohorts_Control_ScanName_vcftools_keepList.txt", sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)

write.table(all_pheno_d, "All_Cohorts_Phenotype.txt", sep = "\t", col.names = TRUE, row.names = FALSE, quote = FALSE)

# write output of each cohort
# table(all_pheno_d$cohort)
#   gem gwas1 gwas2 gwas3 gwas5 
#  2502  2282   618   515   234
write.table(all_pheno_d[all_pheno_d$cohort == "gwas1", "V1"], "GWAS1_ScanName_vcftools_keepList.txt", sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)
write.table(all_pheno_d[all_pheno_d$cohort == "gwas2", "V1"], "GWAS2_ScanName_vcftools_keepList.txt", sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)
write.table(all_pheno_d[all_pheno_d$cohort == "gwas3", "V1"], "GWAS3_ScanName_vcftools_keepList.txt", sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)
write.table(all_pheno_d[all_pheno_d$cohort == "gwas4", "V1"], "GWAS4_ScanName_vcftools_keepList.txt", sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)
write.table(all_pheno_d[all_pheno_d$cohort == "gwas5", "V1"], "GWAS5_ScanName_vcftools_keepList.txt", sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)
write.table(all_pheno_d[all_pheno_d$cohort == "gem", "V1"], "GEM_ScanName_vcftools_keepList.txt", sep = "\t", col.names = FALSE, row.names = FALSE, quote = FALSE)

# write output for PLINK
# colnames(control_d)
control_pheno_d <- control_d[,c("V1", "V1", 
                                "GWAS1_2","GWAS1_3","GWAS1_5","GWAS1_GEM","GWAS2_3","GWAS2_5","GWAS2_GEM","GWAS3_5","GWAS3_GEM","GWAS5_GEM")]
colnames(control_pheno_d) <- c("FID", "IID", 
                               "GWAS1_2","GWAS1_3","GWAS1_5","GWAS1_GEM","GWAS2_3","GWAS2_5","GWAS2_GEM","GWAS3_5","GWAS3_GEM","GWAS5_GEM")
write.table(control_pheno_d, "./pseudoGWAS_input/All_Cohorts_Control_Phenotype_for_PLINK.txt", sep = "\t", col.names = TRUE, row.names = FALSE, quote = FALSE)

################################################################################
### Process each cohort to add in PCs information
################################################################################

# load PCA information
control_PCA <- fread("./pseudoGWAS_input/All_Cohorts_Control_PCA.eigenvec")
control_phenoPC <- merge(control_d_plink, control_PCA, by = intersect(colnames(control_d_plink), colnames(control_PCA)))
control_phenoPC$sex_num_recode <- ifelse(control_phenoPC$sex_recode == "F", 2, 1)
control_phenoPC$race_num_recode <- ifelse(control_phenoPC$race_recode %in% c("W", "White"), 1, 
                                          ifelse(control_phenoPC$race_recode %in% c("B", "Black"), 2, 
                                                 ifelse(control_phenoPC$race_recode == "A", 3, 
                                                               ifelse(control_phenoPC$race_recode %in% c("O", "Other"), 5, 4))))
# table(control_phenoPC$race_num_recode)
#    1    2    3    4    5 
# 3776  161    7   10   41
# sum(is.na(control_phenoPC$race_num_recode))
# 0 

# check PCA
control_racePC <- control_phenoPC[,c("FID", "IID", "race_num_recode", paste0("PC",1:20))]
# table(control_racePC$race)
cols <- rep(NA, nrow(control_racePC))

cols[control_racePC$race == 1] <- "blue" # white
cols[control_racePC$race == 2] <- "red" # black
cols[control_racePC$race == 3] <- "green" # asian
cols[control_racePC$race == 4] <- "orange" # multi-racial
cols[control_racePC$race == 5] <- "grey" # other

control_par.coord <- control_racePC[,c(paste0("PC",1:20))]
control_rangel <- apply(control_par.coord, 2, function(x) range(x)[1])
control_rangeh <- apply(control_par.coord, 2, function(x) range(x)[2])
control_std.coord <- control_par.coord
for (i in 1:14)
  control_std.coord[,i] <- (control_par.coord[,i] - control_rangel[i])/(control_rangeh[i]-control_rangel[i])

pdf("./pseudoGWAS_input/All_Cohorts_Control_N3995_PCA Parallel Coorinates.pdf")
plot(c(0,15), c(0,1), type = 'n', axes = FALSE, ylab = "", xlab = "",
     main = "Parallel Coordinates Plot for GWAS1,2,5,GEM cohorts controls:
     White: blue, Black: red, Asian: green
     Multi-Racial: orange, Other: grey")
for (j in 1:13)
  for (i in sample(1:nrow(control_std.coord)) )
    lines(c(j,j+1), control_std.coord[i,c(j,j+1)], col=cols[i], lwd=0.25)
axis(1, at = 1:14, labels = paste("PC",1:14, sep = "."))
dev.off()

# from the plot, use PC8
control_covar_d <- control_phenoPC[,c("FID", "IID", "sex_num_recode", paste0("PC",1:10))]
str(control_covar_d)
write.table(control_covar_d, "./pseudoGWAS_input/All_Cohorts_Control_Covariates_for_PLINK.txt", sep = "\t", col.names = TRUE, row.names = FALSE, quote = FALSE)

# save.image("All_Cohort_Case_Control_Prep.RData")
load("All_Cohort_Case_Control_Prep.RData")