#!/usr/local/bin/bash

cd /Volumes/Drobo3-5D3/2021_Dec_03_GWAS4_Raw_Data/Imputation_Results

# ###--------------------------------------------------------------------------###
# ###
# ### Post Imputation diagnosis; QC and PCA analysis
# ###
# ###--------------------------------------------------------------------------###
# 
# ### (1) post imputation diagnosis
#  
# # extract post imputation information of a SNP such as MAF, Rsq, and Imputed/Genotyped 
# 
# for i in {1..22} 
# do
# 	zless ./chr_${i}/chr${i}.info.gz |  awk '{OFS="\t"}{print $5, $7, $8, $9, $10, $11, $12, $13}' > chr${i}_info.txt
# done
# 
# # Exam the imputation quality and plot some diagnostic plots
# 
# R CMD BATCH --vanilla ./Post_Imputation_Scripts/2_Distribution_of_Rsq.R
# 
# ### (2) Post imputation QC
# 
# # Select R^2 >= 0.3 variants and wrote it as a file 
# 
# R CMD BATCH --vanilla ./Post_Imputation_Scripts/3_Select_Qualified_SNPs.R
# 
# # select the qualified SNPs, annotate those with rs number and make it as plink file 
# 
# for i in {1..22} 
# do
# 	
#  	vcftools --gzvcf ./chr_${i}/chr${i}.dose.vcf.gz --snps chr_${i}_Qualified_SNPs.txt --recode --recode-INFO-all --out GWAS4_Chr${i}_Qualified_SNPs
# 	bgzip GWAS4_Chr${i}_Qualified_SNPs.recode.vcf	
# 	bcftools annotate -x ID -Oz -o GWAS4_Chr${i}_noID.vcf.gz GWAS4_Chr${i}_Qualified_SNPs.recode.vcf.gz 
# 	tabix -p vcf GWAS4_Chr${i}_noID.vcf.gz
# 	
# done
# 
# # combine all the chromosmes together 
# # create a fiel with Chr1 ~ Chr22 vcf files names 
# 
# echo 'GWAS4_Chr1_noID.vcf.gz
# GWAS4_Chr2_noID.vcf.gz
# GWAS4_Chr3_noID.vcf.gz
# GWAS4_Chr4_noID.vcf.gz
# GWAS4_Chr5_noID.vcf.gz
# GWAS4_Chr6_noID.vcf.gz
# GWAS4_Chr7_noID.vcf.gz
# GWAS4_Chr8_noID.vcf.gz
# GWAS4_Chr9_noID.vcf.gz
# GWAS4_Chr10_noID.vcf.gz
# GWAS4_Chr11_noID.vcf.gz
# GWAS4_Chr12_noID.vcf.gz
# GWAS4_Chr13_noID.vcf.gz
# GWAS4_Chr14_noID.vcf.gz
# GWAS4_Chr15_noID.vcf.gz
# GWAS4_Chr16_noID.vcf.gz
# GWAS4_Chr17_noID.vcf.gz
# GWAS4_Chr18_noID.vcf.gz
# GWAS4_Chr19_noID.vcf.gz
# GWAS4_Chr20_noID.vcf.gz
# GWAS4_Chr21_noID.vcf.gz
# GWAS4_Chr22_noID.vcf.gz' > GWAS4_Chr_VCFs.txt
# 
# # Still have -R in the sample names
# bcftools concat -f GWAS4_Chr_VCFs.txt -Oz -o GWAS4_allChr.vcf.gz
# tabix -p vcf GWAS4_allChr.vcf.gz
# 
# # remove intermediate files 
# rm GWAS4_Chr*_Qualified_SNPs.recode.vcf.gz
# 
# # annotate rs number 
java -jar ~/My_Apps/snpEff_latest_core/snpEff/SnpSift.jar annotate -id ~/Desktop/Ref_DB/dbSNP_vcf/All_20180423.vcf.gz GWAS4_allChr.vcf.gz > GWAS4_AllChr_annotated.vcf

# convert the vcf files to plink file
plink --vcf GWAS4_AllChr_annotated.vcf --make-bed --allow-extra-chr --allow-no-sex --biallelic-only --set-missing-var-ids @:#[b37]\$1,\$2 --out GWAS4_QCed_Annot
 
# clean up intermediate files 

# rm GWAS4_Chr*_noID.vcf.gz*
# rm GWAS4_Chr*.* 

### (3) Make correction on IDs

awk '{print $1, $2}' GWAS4_QCed_Annot.fam > Old_GWAS4_ID.txt
sed 's/-R//g' Old_GWAS4_ID.txt > New_GWAS4_ID.txt
paste -d ' ' Old_GWAS4_ID.txt New_GWAS4_ID.txt > Corrected_GWAS4_ID.txt

plink --bfile GWAS4_QCed_Annot --update-ids Corrected_GWAS4_ID.txt --make-bed --out GWAS4_IDcorrected_QCed_Annot

rm Old_GWAS4_ID.txt New_GWAS4_ID.txt Corrected_GWAS4_ID.txt 

# remove the sample missing all phenotypes
# echo '4204301 4204301' > remove_list.txt

# plink --bfile GEM_IDcorrected_QCed_Annot --remove remove_list.txt --make-bed --out GEM_Genotyped_Samples

### (3) PCA analysis

plink --bfile GEM_Genotyped_Samples --hwe 1E-05 --indep-pairphase 20000 200 0.5 --mind 0.05 --geno 0.05 --maf 0.05 --allow-extra-chr --biallelic-only --out STEP1_PCA

plink --bfile GEM_Genotyped_Samples --allow-extra-chr --biallelic-only --extract STEP1_PCA.prune.in --make-bed --out STEP2_PCA

plink --bfile STEP2_PCA --cluster --genome gz --pca header --neighbour 1 10 --out ../../4_Cleaned_Genotype_Data/GEM_PCA


### (4) Clean up the Genotype data by excluding 100% LD SNPs

plink --bfile GEM_Genotyped_Samples --indep-pairphase 20000 200 0.999 --mind 0.05 --geno 0.05 --allow-extra-chr --biallelic-only --out Eligible_SNPs

plink --bfile GEM_Genotyped_Samples --allow-extra-chr --biallelic-only --extract Eligible_SNPs.prune.in --make-bed --out GEM_Cleaned_w_DupID

# plink --bfile GEM_Genotyped_Samples --hwe 1E-05 --allow-extra-chr --biallelic-only --extract Eligible_SNPs.prune.in --make-bed --out GEM_Cleaned_w_DupID
# --hwe: 97289 variants removed due to Hardy-Weinberg exact test.

# Remove duplicat SNPs
plink2 --bfile GEM_Cleaned_w_DupID --rm-dup force-first --make-bed --out ../../4_Cleaned_Genotype_Data/GEM_All_Cleaned

# cut -f2 ../../4_Cleaned_Genotype_Data/GEM_All_Cleaned.bim | sort | uniq -c | awk '$1>1' > ../../4_Cleaned_Genotype_Data/GEM_Duplicate_SNPs.txt

# clean up intermediate files 
rm Old_GEM_ID.txt New_GEM_ID.txt Corrected_GEM_ID.txt remove_list.txt

rm STEP[1,2]_PCA* rm GEM_QCed_Annot.* GEM_IDcorrected_QCed_Annot.* GEM_Cleaned_w_DupID.*








