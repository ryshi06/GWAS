
###--------------------------------------------------------------------------###
###
###
###
###--------------------------------------------------------------------------###

rm(list=ls())
options(stringsAsFactors = FALSE)

cohorts <- c("GWAS1", "GWAS2", "GWAS3", "GWAS5", "GEM")

###--------------------------------------------------------------------------###

# SNP_list <- NULL
for (cohort in cohorts){
  
  setwd(paste0("/zfs1/kfan/Ruyu/harmonization_Sep5/", cohort, "/QC_check/after_imputationQC/"))
  input_dir <- paste0("/zfs1/kfan/Ruyu/harmonization_Sep5/", cohort, "/impu_output_11272023_withX/")
  output_dir <- paste0("/zfs1/kfan/Ruyu/harmonization_Sep5/", cohort, "/QC_check/after_imputationQC/")
  
  chrs <- c(1:22, "X")
  SNP_list <- list()
  
  for(chr in chrs){
    
    print(paste0("Chromosome ", chr, " processing..."))
    
    d <- read.csv(paste0(input_dir, "chr", chr, "_info.txt"), sep="\t")
    dd <- subset(d, Rsq<0.3)  
    SNP_list[[chr]] <- data.frame(V1 = dd$SNP)
    
  }
  
  SNP_d <- do.call(rbind, SNP_list)
  
  print(paste0("Cohort ", cohort, " finished, and ", nrow(SNP_d), " SNPs are selected based on R2 < 0.3 threshold."))
  write.table(SNP_d, file=paste0(output_dir, cohort, "_R2_threshold03_SNPs.txt"),
              quote=FALSE, row.names = FALSE, col.names = FALSE)
  
  # rm(list=ls())
}  

