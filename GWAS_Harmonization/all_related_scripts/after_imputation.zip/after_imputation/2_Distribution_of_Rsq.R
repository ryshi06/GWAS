
# rm(list=ls())
options(stringsAsFactors = FALSE)

cohorts <- c("GWAS1", "GWAS2", "GWAS3", "GWAS5", "GEM")

for (cohort in cohorts){
  
  # set up directories
  setwd(paste0("/zfs1/kfan/Ruyu/harmonization_Sep5/", cohort, "/QC_check/after_imputationQC/"))
  
  input_dir <- paste0("/zfs1/kfan/Ruyu/harmonization_Sep5/", cohort, "/impu_output_11272023_withX/")
  output_dir <- paste0("/zfs1/kfan/Ruyu/harmonization_Sep5/", cohort, "/QC_check/after_imputationQC/")
  
  ###--------------------------------------------------------------------------###
  
  # plot mean Rsq for all chrs
  pdf(paste0(output_dir, "Mean_Rsq_for_all_chrs.pdf"))
  chrs <- c(1:22, "X")
  for(i in chrs){
    
    d <- read.csv(paste0(input_dir, "chr",i,"_info.txt"), sep="\t")
    d$cat_MAF <- cut(d$MAF, 500)
    mean_Rsq_by_MAF <- tapply(d$Rsq[d$Genotyped!="Genotyped"], d$cat_MAF[d$Genotyped!="Genotyped"], mean)
    
    plot(mean_Rsq_by_MAF, pch=16, cex=.5, las=1, xaxt="n", ylim=c(0,1),
         ylab="Mean R square", xlab="Minor Allele Frequency",
         main=paste0("Chromosome ",i), yaxt="n", sub="Imputed Variants Only")
    axis(1, at=seq(0,500,100), labels=seq(0,0.5,0.1), cex.axis=0.7)
    axis(2, at=seq(0,1,0.1), cex.axis=0.7, las=1)
    
  }
  
  dev.off()
  
  Rsq_All <- NULL
  
  for(i in chrs){
    
    d <- read.csv(paste0(input_dir, "chr",i,"_info.txt"), sep="\t")
    d$Chr <- i
    Rsq_All <- rbind(Rsq_All, d[,c("Chr","Rsq")])
    
  }
  
  pdf(paste0(output_dir, "Rsq_for_all_chrs.pdf"))
  
  par(mar=c(5,5,5,1))
  boxplot(Rsq~Chr, data=Rsq_All, las=1, xaxt="n", ylim=c(0,1),
          ylab=expression("R"^2), xlab="Chromosome",
          main=expression(paste("R"^2," Distribution by Chromosome",sep="")))
  axis(1, at=chrs, cex.axis=0.7)
  
  dev.off()
  
  # table(Rsq_All$Chr)
  
  ###--------------------------------------------------------------------------###
  
  Rsq_Imput <- Rsq_GTed <- NULL
  
  for(i in 1:22){
    
    d <- read.csv(paste0(input_dir, "chr",i,"_info.txt"), sep="\t")
    d$Chr <- i
    
    d2 <- subset(d, Genotyped!="Genotyped")
    Rsq_Imput <- rbind(Rsq_Imput, d2[,c("Chr","MAF","Rsq")])
    
    d3 <- subset(d, Genotyped=="Genotyped")
    Rsq_GTed <- rbind(Rsq_GTed, d3[,c("Chr","MAF","Rsq","LooRsq","EmpR","EmpRsq","Dose0","Dose1")])
    
  }
  
  ###--------------------------------------------------------------------------###
  
  Rsq_Imput$cat_MAF <- cut(Rsq_Imput$MAF, 500)
  mean_Rsq_by_MAF <- tapply(Rsq_Imput$Rsq, Rsq_Imput$cat_MAF, mean)
  
  pdf(paste0(output_dir, "Mean_Rsq.pdf"))
  par(mar=c(5,5,5,1))
  plot(mean_Rsq_by_MAF, pch=16, cex=.5, las=1, xaxt="n", ylim=c(0,1),
       ylab=expression("Mean R"^2), xlab="Minor Allele Frequency",
       main=expression(paste("Mean R"^2," Distribution",sep="")), yaxt="n", sub="Imputed Variants Only")
  axis(1, at=seq(0,500,100), labels=seq(0,0.5,0.1), cex.axis=0.7)
  axis(2, at=seq(0,1,0.1), cex.axis=0.7, las=1)
  dev.off()
  
  ###--------------------------------------------------------------------------###
  
  x <- table(Rsq_Imput$cat_MAF)
  
  pdf(paste0(output_dir, "Variant_Count.pdf"))
  par(mar=c(5,5,5,1))
  plot(1:500, unname(x), pch=16, cex=.5, xaxt="n", ylim=range(x),
       ylab="Variant Counts", xlab="Minor Allele Frequency",
       main="Variant Count Distribution by MAF", yaxt="n", sub="Imputed Variants Only")
  axis(1, at=seq(0,500,100), labels=seq(0,0.5,0.1), cex.axis=0.7)
  axis(2, at=formatC(seq(5E5,250E5, 10E5), format="E", digits = 0), cex.axis=0.7, las=1)
  dev.off()
  
  ###--------------------------------------------------------------------------###
  
  Rsq_GTed$cat_MAF <- cut(Rsq_GTed$MAF, 100)
  x <- table(Rsq_GTed$cat_MAF)
  
  Rsq_GTed$Pass_0.8_LooRsq <- Rsq_GTed$LooRsq>=0.8
  frac_LooRsq_0.8_by_MAF <- tapply(Rsq_GTed$Pass_0.8_LooRsq , Rsq_GTed$cat_MAF, 
                                   function(x){length(which(x==TRUE))/length(x)})
  
  Rsq_GTed$EmpRsq <- as.numeric(Rsq_GTed$EmpRsq)
  mean_EmpRsq_by_MAF <- tapply(Rsq_GTed$EmpRsq, Rsq_GTed$cat_MAF, mean)
  mean_EmpRsq_pass_LooRsq_by_MAF <- tapply(Rsq_GTed$EmpRsq[Rsq_GTed$Pass_0.8_LooRsq==TRUE], 
                                           Rsq_GTed$cat_MAF[Rsq_GTed$Pass_0.8_LooRsq==TRUE], mean)
  
  Rsq_GTed$Dose0 <- as.numeric(Rsq_GTed$Dose0)
  mean_Dose0_by_MAF <- tapply(Rsq_GTed$Dose0, Rsq_GTed$cat_MAF, mean)
  mean_Dose0_pass_LooRsq_by_MAF <- tapply(Rsq_GTed$Dose0[Rsq_GTed$Pass_0.8_LooRsq==TRUE], 
                                          Rsq_GTed$cat_MAF[Rsq_GTed$Pass_0.8_LooRsq==TRUE], mean)
  
  pdf(paste0(output_dir, "Genotyped_Variant.pdf"))
  par(mar=c(5,5,5,1), mfrow=c(2,2))
  
  # P1
  plot(1:100, unname(x), pch=16, cex=.5, xaxt="n", ylim=range(x),
       ylab="Variant Counts", xlab="Minor Allele Frequency",
       main="Variant Count Distribution by MAF", yaxt="n", sub="Genotyped Variants",
       cex.main=0.8, cex.lab=0.8, cex.sub=0.8, font.main=1)
  axis(1, at=seq(0,100,20), labels=seq(0,0.5,0.1), cex.axis=0.7)
  axis(2, at=formatC(seq(5E3,25E4, 10E3), format="E", digits = 0), cex.axis=0.7, las=1)
  
  
  # P2
  plot(1:100, frac_LooRsq_0.8_by_MAF, pch=16, cex=.5, xaxt="n", ylim=c(0.7,1),
       ylab=expression("fraction of SNPs with LooR"^2>=0.8), xlab="Minor Allele Frequency",
       main=expression(paste("Fraction of LooR"^2>=0.8," by MAF",sep="")), yaxt="n", sub="Genotyped Variants",
       cex.main=0.8, cex.lab=0.8, cex.sub=0.8, font.main=1)
  axis(1, at=seq(0,100,20), labels=seq(0,0.5,0.1), cex.axis=0.7)
  axis(2, at=seq(0.6,1,0.1), cex.axis=0.7, las=1)
  
  # P3
  plot(1:100, mean_EmpRsq_by_MAF, pch=16, cex=.5, xaxt="n", ylim=c(0.7,1),
       ylab=expression(paste("empirical R"^2, " (EmpR"^2, ")",sep="")), xlab="Minor Allele Frequency",
       main=expression(paste("empirical R"^2, " (EmpR"^2, ")"," by MAF",sep="")), yaxt="n", sub="Genotyped Variants",
       cex.main=0.8, cex.lab=0.8, cex.sub=0.8, font.main=1)
  axis(1, at=seq(0,100,20), labels=seq(0,0.5,0.1), cex.axis=0.7)
  axis(2, at=seq(0.6,1,0.1), cex.axis=0.7, las=1)
  points(1:100, mean_EmpRsq_pass_LooRsq_by_MAF, pch=17, col="gray", cex=0.5)
  
  # P4
  plot(1:100, mean_Dose0_by_MAF, pch=16, cex=.5, xaxt="n", ylim=c(0.7,1),
       ylab="Dose0", xlab="Minor Allele Frequency",
       main="Dose0 by MAF", yaxt="n", sub="Genotyped Variants",
       cex.main=0.8, cex.lab=0.8, cex.sub=0.8, font.main=1)
  axis(1, at=seq(0,100,20), labels=seq(0,0.5,0.1), cex.axis=0.7)
  axis(2, at=seq(0.6,1,0.1), cex.axis=0.7, las=1)
  points(1:100, mean_Dose0_pass_LooRsq_by_MAF, pch=17, col="gray", cex=0.5)
  
  dev.off()
  
  ###--------------------------------------------------------------------------###
  
  print(paste0("Cohort ", cohort, " finished, saving R working space."))
  
  rm(list=setdiff(ls(),c("Rsq_All","Rsq_Imput","Rsq_GTed")))
  save.image("Imputation_QC_Data.RData")
  
  ###--------------------------------------------------------------------------###
  
}








