###--------------------------------------------------------------------------###
###
###
###
###--------------------------------------------------------------------------###

rm(list=ls())
options(stringsAsFactors = FALSE)
setwd("~/Desktop/Pitt_Projects/GEM_GWAS/Data/Genotype_Data/Imputation/Result_from_Michigan_Server/")

###--------------------------------------------------------------------------###

# list.files(pattern = ".bim")

annot_trans <- function(x){
  
  wd <- unlist(strsplit(x, split=";"))
  if(length(wd)>1){
    return(wd[2])
  }else{
    return(wd[1])
  }
  
}

###--------------------------------------------------------------------------###

for(i in 1:22){

  d <- read.csv(paste0("GEM_Chr",i,".bim"), sep="\t", header = FALSE)

  old_id <- d$V2
  new_id <- unname(sapply(old_id, annot_trans))

  new_names <- cbind(old_id, new_id)

  write.table(new_names, paste0("GEM_Chr",i,"newid.txt"), quote=FALSE, row.names=FALSE, col.names = FALSE, sep = " ")

  }

###--------------------------------------------------------------------------###


