
### extract case/control samples' ID from each cohort to prepare pseudoGWAS file

output_dir <- "/zfs1/kfan/Ruyu/harmonization_Sep5/All_Cohorts/pseudoGWAS_input"

extract_before_underscore <- function(x) {
  parts <- unlist(strsplit(x, "_"))
  if (length(parts) > 1) {
    return(parts[1])
  } else {
    return(x)
  }
}

# create a dataframe documenting GEM & GWAS batches sample info
GEM_GWAS_PHENO <- data.frame(AlzID = NA, scanName = NA, LabID = NA, StudyID = NA, Study = NA, APOE = NA, Sex = NA, Race = NA, Case_Control = NA, 
                             QC_status = NA, QC_comment = NA, GWAS1 = NA, GWAS2 = NA, GWAS3 = NA, GWAS4 = NA, GWAS5 = NA, GEM = NA)

required_cols <- colnames(GEM_GWAS_PHENO)

### GWAS1
GWAS_pheno <- read.csv("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS_Clinical_Reference/GWAS_Reference_Data/GWAS_ALL_2023_07_24.csv")
# GWAS_1_pheno <- GWAS_pheno[GWAS_pheno$GWAS_1 == "Y",]
GWAS_1_fam <- read.table("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS1/GWAS_1_raw_01.fam", header = FALSE)
GWAS_1_fam$LabID <- sapply(GWAS_1_fam$V1, extract_before_underscore)

GWAS_1_fam_full <- read.table("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS_Clinical_Reference/GWAS_Reference_Data/Omni1-quad_07_01_2010_GenTrain_2_Kamboh_case_control.fam", 
                              header = FALSE)
# length(intersect(toupper(sapply(GWAS_1_fam$V1, extract_before_underscore)), toupper(GWAS_1_pheno$LabID)))
# # 1871
length(intersect(toupper(sapply(GWAS_1_fam$V1, extract_before_underscore)), toupper(GWAS_pheno$LabID)))
# 1976
setdiff(toupper(sapply(GWAS_1_fam$V1, extract_before_underscore)), toupper(GWAS_pheno$LabID))
openxlsx::write.xlsx(as.data.frame(GWAS_1_ids), paste0(output_dir, "/GWAS_1_ID.xlsx"))

# note: updates from Dec 14, requested case-control status from Lynda
GWAS1_DataRequest <- openxlsx::read.xlsx("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS_Clinical_Reference/GWAS_Reference_Data/V_DataRequest_Ruyu_GWAS_1_Phenotype_2023_12_14.xlsx")
table(GWAS1_DataRequest$Case_Control)
# length(intersect(toupper(GWAS1_DataRequest$LabID), toupper(GWAS_1_ids)))
# length(setdiff(toupper(GWAS1_DataRequest$LabID), toupper(GWAS_1_ids)))

GWAS_1_pheno <- merge(GWAS1_DataRequest[!(GWAS1_DataRequest$Study %in% "MOVIES"),], GWAS_1_fam[,c("LabID", "V2")], 
                      by = "LabID", all.x = TRUE)
GWAS_1_pheno_MOVIES <- GWAS1_DataRequest[GWAS1_DataRequest$Study %in% "MOVIES",]
GWAS_1_pheno_MOVIES$old_LabID <- sub("M", "M0", GWAS_1_pheno_MOVIES$LabID)
GWAS_1_pheno_MOVIES <- merge(GWAS_1_pheno_MOVIES, GWAS_1_fam[,c("LabID", "V2")], 
                      by.x = "old_LabID", by.y = "LabID", all.x = TRUE)
GWAS_1_pheno <- rbind(GWAS_1_pheno, GWAS_1_pheno_MOVIES[, which(colnames(GWAS_1_pheno_MOVIES) %in% colnames(GWAS_1_pheno))])
# colnames(GWAS_1_pheno)
GWAS_1_pheno$QC_status <- "PASS"
GWAS_1_pheno$QC_comment <- NA
GWAS_1_pheno$GWAS1 <- "Y"
GWAS_1_pheno$GWAS2 <- NA
GWAS_1_pheno$GWAS3 <- NA
GWAS_1_pheno$GWAS4 <- NA
GWAS_1_pheno$GWAS5 <- NA
GWAS_1_pheno$GEM <- NA

names(GWAS_1_pheno)[names(GWAS_1_pheno) == 'V2'] <- 'scanName'

GWAS_1_QC_failed <- data.frame(AlzID = NA, LabID = setdiff(GWAS_1_fam_full$V1, GWAS_1_fam$LabID), scanName = GWAS_1_fam_full[GWAS_1_fam_full$V1 %in% setdiff(GWAS_1_fam_full$V1, GWAS_1_fam$LabID),]$V2, 
                               StudyID = NA, Study = NA, APOE = NA, Sex = NA, Race = NA, Case_Control = NA, QC_status = "FAIL", QC_comment = "removed due to high genotype missingness with plink command --geno 0.1", 
                               GWAS1 = "Y", GWAS2 = "N", GWAS3 = "N", GWAS4 = "N", GWAS5 = "N", GEM = "N")

GWAS_1_pheno_final <- rbind(GWAS_1_pheno[, match(required_cols, colnames(GWAS_1_pheno)), drop = FALSE], 
                            GWAS_1_QC_failed[, match(required_cols, colnames(GWAS_1_QC_failed)), drop = FALSE])
# nrow(GWAS_1_pheno_final)
# 2440

### GWAS2
load("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS2/GWAS_2_Annotation.RData")
# View(scanAnnot@data)

GWAS_2_ex_subjs <- c(
  # high missing.e1
  "g0782", "g0968", 
  # duplicates
  "g0954", "g0832", "g0909", "g0334", "g0338", "g0343", "g0347")

GWAS_2_pheno_final <- scanAnnot@data
GWAS_2_pheno_final$QC_status <- ifelse(GWAS_2_pheno_final$scanName %in% GWAS_2_ex_subjs, "FAIL", "PASS")
GWAS_2_pheno_final$QC_comment <- ifelse(GWAS_2_pheno_final$scanName %in% c("g0782", "g0968"), "removed due to high missing.e1 (missing.e1 > 0.05)", 
                                        ifelse(GWAS_2_pheno_final$scanName %in% c("g0954", "g0832", "g0909", "g0334", "g0338", "g0343", "g0347"), "removed due to wrong phenotype info in the duplicated pair", NA))
colnames(GWAS_2_pheno_final) <- c("scanID","scanName","file","Sex","Race","AlzID","StudyID","LabID","Case_Control","Disease_Status","APOE","QC_status","QC_comment")
GWAS_2_pheno_final$GWAS1 <- NA
GWAS_2_pheno_final$GWAS2 <- "Y"
GWAS_2_pheno_final$GWAS3 <- NA
GWAS_2_pheno_final$GWAS4 <- NA
GWAS_2_pheno_final$GWAS5 <- NA
GWAS_2_pheno_final$GEM <- NA

# setdiff(required_cols, colnames(GWAS_2_pheno_final))
GWAS_2_pheno_final$Study <- NA

GWAS_2_pheno_final <- GWAS_2_pheno_final[, match(required_cols, colnames(GWAS_2_pheno_final)), drop = FALSE]
# table(GWAS_2_pheno_final$QC_comment)

GWAS_2_pheno <- scanAnnot@data[!(scanAnnot@data$scanName %in% GWAS_2_ex_subjs),]
table(GWAS_2_pheno$Case_Control)
#      -1    Case Control 
#       1      80     630 

GWAS_2_case <- cbind(as.data.frame(GWAS_2_pheno[GWAS_2_pheno$Case_Control == "Case", ]$scanName),
                     as.data.frame(GWAS_2_pheno[GWAS_2_pheno$Case_Control == "Case", ]$scanName))
colnames(GWAS_2_case) <- c("FID", "IID")
write.table(GWAS_2_case, paste0(output_dir, "/GWAS_2_case_ID_forPLINK.txt"), 
            col.names = TRUE, row.names = FALSE, quote = FALSE)

GWAS_2_control <- cbind(as.data.frame(GWAS_2_pheno[GWAS_2_pheno$Case_Control == "Control", ]$scanName),
                        as.data.frame(GWAS_2_pheno[GWAS_2_pheno$Case_Control == "Control", ]$scanName))
colnames(GWAS_2_control) <- c("FID", "IID")
write.table(GWAS_2_control, paste0(output_dir, "/GWAS_2_control_ID_forPLINK.txt"), 
            col.names = TRUE, row.names = FALSE, quote = FALSE)

### GWAS3
load("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS3/GWAS_3_Annotation.RData")
# View(scanAnnot@data)

GWAS_3_ex_subjs <- c(
  # high missing.e1
  "6037275","6206921","6208118","6209734","6210171","6210309","6214010","6214843","6215610","6216315",
  "6216960","6216978","6218210","6219683","6219721","a0390","a1713","a1812","a2255","a3013",
  "s0284","s0324","s0337","s0339","s0358",
  # duplicates 
  "6205240", "6207537")

GWAS_3_pheno_final <- scanAnnot@data
GWAS_3_pheno_final$QC_status <- ifelse(GWAS_3_pheno_final$scanName %in% GWAS_3_ex_subjs, "FAIL", "PASS")
GWAS_3_pheno_final$QC_comment <- ifelse(GWAS_3_pheno_final$scanName %in% c("6037275","6206921","6208118","6209734","6210171","6210309","6214010","6214843","6215610","6216315",
                                                                           "6216960","6216978","6218210","6219683","6219721","a0390","a1713","a1812","a2255","a3013",
                                                                           "s0284","s0324","s0337","s0339","s0358"), "removed due to high missing.e1 (missing.e1 > 0.05)", 
                                        ifelse(GWAS_3_pheno_final$scanName %in% c("6205240", "6207537"), "removed due to wrong phenotype info in the duplicated pair", NA))
colnames(GWAS_3_pheno_final) <- c("scanID","scanName","file","Sex","Race","AlzID","StudyID","LabID","Case_Control","Disease_Status","APOE","QC_status","QC_comment")
GWAS_3_pheno_final$GWAS1 <- NA
GWAS_3_pheno_final$GWAS2 <- NA
GWAS_3_pheno_final$GWAS3 <- "Y"
GWAS_3_pheno_final$GWAS4 <- NA
GWAS_3_pheno_final$GWAS5 <- NA
GWAS_3_pheno_final$GEM <- NA

# setdiff(required_cols, colnames(GWAS_3_pheno_final))
GWAS_3_pheno_final$Study <- NA

GWAS_3_pheno_final <- GWAS_3_pheno_final[, match(required_cols, colnames(GWAS_3_pheno_final)), drop = FALSE]
# table(GWAS_3_pheno_final$QC_comment)

GWAS_3_pheno <- scanAnnot@data[!(scanAnnot@data$scanName %in% GWAS_3_ex_subjs),]
table(GWAS_3_pheno$Case_Control)
# -1    Case Control 
#  1     383     229 

GWAS_3_case <- cbind(as.data.frame(GWAS_3_pheno[GWAS_3_pheno$Case_Control == "Case", ]$scanName),
                     as.data.frame(GWAS_3_pheno[GWAS_3_pheno$Case_Control == "Case", ]$scanName))
colnames(GWAS_3_case) <- c("FID", "IID")
write.table(GWAS_3_case, paste0(output_dir, "/GWAS_3_case_ID_forPLINK.txt"), 
            col.names = TRUE, row.names = FALSE, quote = FALSE)

GWAS_3_control <- cbind(as.data.frame(GWAS_3_pheno[GWAS_3_pheno$Case_Control == "Control", ]$scanName),
                        as.data.frame(GWAS_3_pheno[GWAS_3_pheno$Case_Control == "Control", ]$scanName))
colnames(GWAS_3_control) <- c("FID", "IID")
write.table(GWAS_3_control, paste0(output_dir, "/GWAS_3_control_ID_forPLINK.txt"), 
            col.names = TRUE, row.names = FALSE, quote = FALSE)

### GWAS4
load("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS4/GWAS_4_Annotation.RData")

GWAS_4_pheno_final <- scanAnnot@data
GWAS_4_pheno_final$QC_status <- NA
GWAS_4_pheno_final$QC_comment <- NA

GWAS_4_Clinical <- read.csv("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS4/GWAS_4_Clinical_Info_updated_2023_12_13.csv")
# length(intersect(GWAS_4_Clinical$V1, GWAS_4_pheno_final$scanName))
GWAS_4_DataRequest <- openxlsx::read.xlsx("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS_Clinical_Reference/GWAS_Reference_Data/V_DataRequest_Ruyu_GWAS4_2023_12_05.xlsx") 
# length(intersect(GWAS_4_Clinical$AlzID, GWAS_4_DataRequest$AlzID_Provided))
GWAS_4_Data <- merge(GWAS_4_Clinical, GWAS_4_DataRequest[,c("AlzID_Provided", "StudyID_Provided", "Study_Provided", "GWAS_1", "GWAS_2", "GWAS_3", "GWAS_4", "GWAS_5", "GWAS_GEM")], 
                     by.x = "AlzID", by.y = "AlzID_Provided", all.x = TRUE) %>%
  distinct()
GWAS_4_Data <- GWAS_4_Data[!duplicated(GWAS_4_Data$V1, fromLast = TRUE), ]
# length(intersect(GWAS_4_Data$V1, GWAS_4_pheno_final$scanName))
colnames(GWAS_4_Data) <- c("AlzID","scanName","Study","Sex","Race","Disease_Status","Case_Control_Baseline","Case_Control_Current","StudyID","Study_Provided","GWAS1","GWAS2","GWAS3","GWAS4","GWAS5","GEM")  

GWAS_4_pheno_final <- merge(GWAS_4_pheno_final, GWAS_4_Data[,c("AlzID","scanName","Study","StudyID","GWAS1","GWAS2","GWAS3","GWAS4","GWAS5","GEM")], by = "scanName")
colnames(GWAS_4_pheno_final) <- c("scanName","file","Sex", "Race","Case_Control_Baseline","Case_Control","Disease_Status","plate","well_position","scanID","QC_status","QC_comment",
                                  "AlzID","Study","StudyID","GWAS1","GWAS2", "GWAS3","GWAS4","GWAS5","GEM")

# setdiff(required_cols, colnames(GWAS_4_pheno_final))
GWAS_4_pheno_final$LabID <- NA
GWAS_4_pheno_final$APOE <- NA

GWAS_4_pheno_final <- GWAS_4_pheno_final[, match(required_cols, colnames(GWAS_4_pheno_final)), drop = FALSE]
# table(GWAS_4_pheno_final$QC_comment)

### GWAS5
load("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS5/GWAS_5_Annotation.RData")
# View(scanAnnot@data)

GWAS_5_ex_subjs <- c(
  # high missing.e1
  # duplicates 
  "IGN598", "IGN749", "IGN751")

GWAS_5_pheno_final <- scanAnnot@data

GWAS_5_pheno_final$QC_status <- ifelse(GWAS_5_pheno_final$scanName %in% GWAS_5_ex_subjs, "FAIL", "PASS")
GWAS_5_pheno_final$QC_comment <- ifelse(GWAS_5_pheno_final$scanName %in% c("IGN598", "IGN749", "IGN751"), "removed due to wrong phenotype info in the duplicated pair", NA)
colnames(GWAS_5_pheno_final) <- c("scanName","scanID","file","Sex","Race","AlzID","StudyID","LabID","Case_Control","Disease_Status","APOE","plate","well","QC_status","QC_comment")
GWAS_5_pheno_final$GWAS1 <- NA
GWAS_5_pheno_final$GWAS2 <- NA
GWAS_5_pheno_final$GWAS3 <- NA
GWAS_5_pheno_final$GWAS4 <- NA
GWAS_5_pheno_final$GWAS5 <- "Y"
GWAS_5_pheno_final$GEM <- NA

# setdiff(required_cols, colnames(GWAS_5_pheno_final))
GWAS_5_pheno_final$Study <- NA

GWAS_5_pheno_final <- GWAS_5_pheno_final[, match(required_cols, colnames(GWAS_5_pheno_final)), drop = FALSE]
# table(GWAS_5_pheno_final$QC_comment)

GWAS_5_pheno <- scanAnnot@data[!(scanAnnot@data$scanName %in% GWAS_5_ex_subjs),]
table(GWAS_5_pheno$Case_Control)
# Case Control 
#    3     231  
sum(is.na(GWAS_5_pheno$Case_Control))
# 11

GWAS_5_case <- cbind(as.data.frame(GWAS_5_pheno[GWAS_5_pheno$Case_Control == "Case" & !is.na(GWAS_5_pheno$Case_Control), ]$scanName),
                     as.data.frame(GWAS_5_pheno[GWAS_5_pheno$Case_Control == "Case" & !is.na(GWAS_5_pheno$Case_Control), ]$scanName))
colnames(GWAS_5_case) <- c("FID", "IID")
write.table(GWAS_5_case, paste0(output_dir, "/GWAS_5_case_ID_forPLINK.txt"), 
            col.names = TRUE, row.names = FALSE, quote = FALSE)

GWAS_5_control <- cbind(as.data.frame(GWAS_5_pheno[GWAS_5_pheno$Case_Control == "Control" & !is.na(GWAS_5_pheno$Case_Control), ]$scanName),
                        as.data.frame(GWAS_5_pheno[GWAS_5_pheno$Case_Control == "Control" & !is.na(GWAS_5_pheno$Case_Control), ]$scanName))
colnames(GWAS_5_control) <- c("FID", "IID")
write.table(GWAS_5_control, paste0(output_dir, "/GWAS_5_control_ID_forPLINK.txt"), 
            col.names = TRUE, row.names = FALSE, quote = FALSE)

### GEM
load("/zfs1/kfan/Ruyu/harmonization_Sep5/GEM/QC_check/GEM_GWAS_QC.RData")
# View(scanAnnot@data)

# GEM_ex_subjs <- c(
#   # failed genotyping
#   "6209831", 
#   # high missing.e1
#   "4200276","6205860","6206220","5202582","4205170","4213572","6207421","4205952","3045420","5201721","3200639"
#   # 51 duplicates)

GEM_pheno_final <- scanAnnot@data
GEM_in_subjs <- elig_subj
GEM_pheno_final <- scanAnnot@data
GEM_pheno_final$QC_status <- ifelse(GEM_pheno_final$scanName %in% scanAnnot@data$scanName[GEM_in_subjs], "PASS", "FAIL")
GEM_pheno_final$QC_comment <- ifelse(GEM_pheno_final$scanName %in% c("4200276","6205860","6206220","5202582","4205170","4213572","6207421","4205952","3045420","5201721","3200639"), "removed due to high missing.e1 (missing.e1 > 0.05)", 
                                     ifelse(GEM_pheno_final$scanName %in% c("6209831"), "removed due to failed genotyping", NA))
GEM_pheno_final[GEM_pheno_final$QC_status == "FAIL",]$QC_comment <- ifelse(is.na(GEM_pheno_final[GEM_pheno_final$QC_status == "FAIL",]$QC_comment), "removed due to identified as duplicates by genotype data", GEM_pheno_final[GEM_pheno_final$QC_status == "FAIL",]$QC_comment)
table(GEM_pheno_final$QC_status)
table(GEM_pheno_final$QC_comment)

colnames(GEM_pheno_final) <- c("scanID","scanName","file","Sex","Race","age","Case_Control","dementia","plate","well_position","edu","center","cdr","weight","height","bmi","GEMID","corrected_scanName","QC_status","QC_comment")

GEM_pheno_final$GWAS1 <- NA
GEM_pheno_final$GWAS2 <- NA
GEM_pheno_final$GWAS3 <- NA
GEM_pheno_final$GWAS4 <- NA
GEM_pheno_final$GWAS5 <- NA
GEM_pheno_final$GEM <- "Y"

# setdiff(required_cols, colnames(GEM_pheno_final))
GEM_pheno_final$Study <- NA
GEM_pheno_final$AlzID <- NA
GEM_pheno_final$LabID <- NA
GEM_pheno_final$StudyID <- NA
GEM_pheno_final$APOE <- NA

GEM_pheno_final <- GEM_pheno_final[, match(required_cols, colnames(GEM_pheno_final)), drop = FALSE]
# table(GEM_pheno_final$QC_comment)

GEM_pheno <- scanAnnot@data[scanAnnot@data$scanName %in% scanAnnot@data$scanName[GEM_in_subjs],]
table(GEM_pheno$AD)
#  AD Control 
# 407    2330
sum(is.na(GEM_pheno$AD))
# 1
table(GEM_pheno$dementia)
#  AD Control  Non-AD 
# 407    2290      40 

GEM_case <- cbind(as.data.frame(GEM_pheno[GEM_pheno$AD == "AD" & !is.na(GEM_pheno$AD), ]$scanName),
                     as.data.frame(GEM_pheno[GEM_pheno$AD == "AD" & !is.na(GEM_pheno$AD), ]$scanName))
colnames(GEM_case) <- c("FID", "IID")
write.table(GEM_case, paste0(output_dir, "/GEM_case_ID_forPLINK.txt"), 
            col.names = TRUE, row.names = FALSE, quote = FALSE)

GEM_control <- cbind(as.data.frame(GEM_pheno[GEM_pheno$AD == "Control" & !is.na(GEM_pheno$AD), ]$scanName),
                        as.data.frame(GEM_pheno[GEM_pheno$AD == "Control" & !is.na(GEM_pheno$AD), ]$scanName))
colnames(GEM_control) <- c("FID", "IID")
write.table(GEM_control, paste0(output_dir, "/GEM_control_ID_forPLINK.txt"), 
            col.names = TRUE, row.names = FALSE, quote = FALSE)

### ----- 
# rbind all cohorts
All_Cohorts_GWAS_list <- list(GWAS_1_pheno_final, 
                              GWAS_2_pheno_final, 
                              GWAS_3_pheno_final, 
                              GWAS_4_pheno_final, 
                              GWAS_5_pheno_final, 
                              GEM_pheno_final)
All_Cohorts_GWAS <- data.table::rbindlist(All_Cohorts_GWAS_list)
# add-in additional case_control information from 2023-12-14 data request

supp_dataRequest <- openxlsx::read.xlsx("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS_Clinical_Reference/GWAS_Reference_Data/V_DataRequest_Ruyu_GWAS_CaseControl_2023_12_14.xlsx")


supp_dataRequest_GWAS5 <- supp_dataRequest[supp_dataRequest$LabID %in% c("cPiB148", "cPiB173", "cPiB179", "cPiB180", "cPiB181", "cPiB190", "cPiB218", "cPiB231", "cPiB241"),]
supp_dataRequest_GWAS5$labID <- sub("cPiB", "cPib", supp_dataRequest_GWAS5$LabID)
colnames(supp_dataRequest_GWAS5) <- c("AlzID","LabID","StudyID","Study","Prev_LabID","Case_Control_Baseline","Case_Control","Case_Control_Comments","Last_CDR_Score","labID")

GWAS_5_pheno_final_supp <- merge(GWAS_5_pheno_final[GWAS_5_pheno_final$scanName %in% supp_dataRequest_GWAS5$labID, 
                                                    which(colnames(GWAS_5_pheno_final) %in% c("scanName","APOE","Sex","Race","QC_status","QC_comment","GWAS1","GWAS2","GWAS3","GWAS4","GWAS5","GEM"))],
                                 supp_dataRequest_GWAS5[,c("AlzID", "labID", "LabID","StudyID", "Study", "Case_Control")], by.x = "scanName", by.y = "labID", )

All_Cohorts_GWAS_update <- rbind(All_Cohorts_GWAS[!(All_Cohorts_GWAS$scanName %in% supp_dataRequest_GWAS5$labID),], 
                                 GWAS_5_pheno_final_supp[, match(required_cols, colnames(GWAS_5_pheno_final_supp)), drop = FALSE])

# manually fix LabID == "6206972"
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$scanName == "6206972", ]$Case_Control <- "Control"
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$scanName == "6206972", ]$AlzID <- "ALZ103251"
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$scanName == "6206972", ]$LabID <- "6206972"
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$scanName == "6206972", ]$Study <- "GEM"
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$scanName == "6206972", ]$StudyID <- "6206972"

# manually fix ALZ100923 & ALZ100914
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$AlzID == "ALZ100923", ]$LabID <- "BACN0313"
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$AlzID == "ALZ100914", ]$LabID <- "BACN0275"

# manually fix ALZ106714
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$AlzID == "ALZ106714", ]$Case_Control <- "Case"
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$AlzID == "ALZ106714", ]$Study <- "ADRC"

# manually fix ALZ113263
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$AlzID == "ALZ113263", ]$Case_Control <- "Control"
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$AlzID == "ALZ113263", ]$Study <- "MYHAT"

# table(All_Cohorts_GWAS_update$Case_Control) 
All_Cohorts_GWAS_update[All_Cohorts_GWAS_update$Case_Control == "AD",]$Case_Control <- "Case"
openxlsx::write.xlsx(All_Cohorts_GWAS_update, paste0(output_dir,"/All_Cohorts_GWAS_Phenotype_Info_2023_12_14.xlsx"))

nrow(GEM_pheno_final) + nrow(GWAS_1_pheno_final) + nrow(GWAS_2_pheno_final) + nrow(GWAS_3_pheno_final) + nrow(GWAS_4_pheno_final) + nrow(GWAS_5_pheno_final)
# 11387 

save.image(paste0(output_dir, "/All_Cohorts_Case_Control_IDs_Prep.RData"))

### 2023-12-22 update

# read in data from Lynda
gwas_all_retrieved <- openxlsx::read.xlsx("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS_Clinical_Reference/V_DataRequest_Ruyu_GWAS_Info_2023_12_20.xlsx")
# gwas4_retrieved_subset <- subset(gwas_all_retrieved, GWAS4 == "Y")

# sum(is.na(gwas_all_retrieved$AlzID_DB))
# 97
# View(gwas_all_retrieved[is.na(gwas_all_retrieved$AlzID_DB), ])

# table(duplicated(gwas_all_retrieved$AlzID_DB))
# FALSE  TRUE 
# 10739   648 
# duplicated_AlzID_DB_original <- gwas_all_retrieved[gwas_all_retrieved$AlzID_DB %in% gwas_all_retrieved$AlzID_DB[duplicated(gwas_all_retrieved$AlzID_DB) | duplicated(gwas_all_retrieved$AlzID_DB, fromLast = TRUE)], ]
# openxlsx::write.xlsx(duplicated_AlzID_DB[order(duplicated_AlzID_DB$AlzID_DB), ], "/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS_Clinical_Reference/duplicated_V_DataRequest_Ruyu_GWAS_Info_2023_12_20.xlsx")
# View(gwas_all_retrieved[gwas_all_retrieved$AlzID_DB %in% duplicated(gwas_all_retrieved$AlzID_DB), ])

duplicated_AlzID_DB_modified <- openxlsx::read.xlsx("/zfs1/kfan/Ruyu/harmonization_Sep5/GWAS_Clinical_Reference/duplicated_V_DataRequest_Ruyu_GWAS_Info_2023_12_20.xlsx")
table(is.na(duplicated_AlzID_DB_modified$AlzID_DB))
# FALSE  TRUE 
#  1059    97

# table(duplicated_AlzID_DB_modified$QC_Status)
# FAIL PASS 
 # 122  846
# sum(is.na(duplicated_AlzID_DB_modified$QC_Status))
# 188

duplicated_AlzID_DB_modified_pass <- subset(duplicated_AlzID_DB_modified, QC_Status != "FAIL")
duplicated_AlzID_DB_modified_miss <- subset(duplicated_AlzID_DB_modified, is.na(QC_Status))

duplicated_AlzID_DB_modified_nofail <- rbind(duplicated_AlzID_DB_modified_pass, duplicated_AlzID_DB_modified_miss)
duplicated_AlzID_DB_modified_nofail_differs <- duplicated_AlzID_DB_modified_nofail[!is.na(duplicated_AlzID_DB_modified_nofail$Flag_Sex) | !is.na(duplicated_AlzID_DB_modified_nofail$Flag_Race) | !is.na(duplicated_AlzID_DB_modified_nofail$Flag_APOE), ]


duplicated_AlzID_DB_original_differs <- duplicated_AlzID_DB_original[duplicated_AlzID_DB_original$AlzID_DB %in% duplicated_AlzID_DB_modified_nofail_differs$AlzID_DB,]
duplicated_AlzID_DB_original_consistent <- duplicated_AlzID_DB_original[!(duplicated_AlzID_DB_original$AlzID_DB %in% duplicated_AlzID_DB_modified_nofail_differs$AlzID_DB),]

d <- duplicated_AlzID_DB_modified_pass[duplicated_AlzID_DB_modified_pass$AlzID_DB %in% duplicated_AlzID_DB_original_consistent$AlzID_DB, ]















