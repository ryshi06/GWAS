
library(data.table)

setwd("/ix/kfan/Ruyu/harmonization/")

###--------------------------------------------------------------------------###
### generate final lists of problematic samples from harmonization
###--------------------------------------------------------------------------###

# 05/24/2024

oldRef <- openxlsx::read.xlsx("/ix/kfan/Ruyu/harmonization/All_Cohorts/V_DataRequest_Ruyu_GWAS_Info_2023_12_20.xlsx")
pheno <- fread("./All_Cohorts/All_Cohorts_2nd_Imputation_Phenotype.txt")
apoe24 <- openxlsx::read.xlsx("./All_Cohorts/APOE24_Sample_Characteristics_for_TabPrep_N15186.xlsx")

batches <- c(paste0("GWAS",1:5), "GEM")

# get the exclude lists
exclude.list <- list()

for (batch in batches){
  exclude.list[[batch]] <- openxlsx::read.xlsx("Harmonization_Sample_Stats.xlsx", sheet = batch)
}

exclude.dd <- do.call(rbind, exclude.list)
unique(exclude.dd$Removal.Reasons)
rownames(exclude.dd) <- NULL

exclude.dd$SampleID <- gsub("R", " R", exclude.dd$SampleID)
exclude.dd$SampleID <- gsub(" R0", "R0", exclude.dd$SampleID)
exclude.dd$SampleID <- gsub("- R", "-R", exclude.dd$SampleID)

### list 1 (N=219): Missing call rate > 5%

missing_call_rate_ex <- exclude.dd[exclude.dd$Removal.Reasons == "Missing call rate > 5%", ]
length(unique(missing_call_rate_ex$SampleID))

length(intersect(missing_call_rate_ex$SampleID, oldRef$Scan_Name))
missing_call_rate_ex2 <- merge(missing_call_rate_ex[,c("SampleID","Removal.Reasons")], 
                               oldRef[,c("Scan_Name", "AlzID_DB", "StudyID_DB", "LabID_DB", "Study")], 
                               by.x = "SampleID", by.y = "Scan_Name") %>% distinct()
missing_call_rate_ex3 <- missing_call_rate_ex2[-(missing_call_rate_ex2$SampleID == "A0035" & is.na(missing_call_rate_ex2$Study)), ]
missing_call_rate_ex4 <- missing_call_rate_ex3[-(missing_call_rate_ex2$SampleID == "A0630" & is.na(missing_call_rate_ex2$Study)), ]

missing_call_rate_ex4$Study <- ifelse(!is.na(missing_call_rate_ex4$Study), missing_call_rate_ex4$Study, 
                                      ifelse(grep("S", missing_call_rate_ex4$LabID_DB), "SARP", 
                                             ifelse(grep("A|B", missing_call_rate_ex4$LabID_DB), "ADRC", "GEM")))

table(missing_call_rate_ex4$Study)

### list 2 (N=63): Sex Mismatch

sex_mismatch_ex <- exclude.dd[exclude.dd$Removal.Reasons == "mislabeled sex", ]
length(unique(sex_mismatch_ex$SampleID))

length(intersect(sex_mismatch_ex$SampleID, oldRef$Scan_Name))

### list 3 (N=39+1340 after checking BENIN and SLVDS): Race Discrepancies

### list 4 (N = 1035+329): APOE discrepancies