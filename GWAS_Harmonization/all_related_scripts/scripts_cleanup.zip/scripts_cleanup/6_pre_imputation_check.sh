#!/bin/bash                                     

################################################################
### this file is used to format VCF files for Michigan Imputation Server
### 	HRC Pre-imputation Checks
###
### Note: 
### 	from https://imputationserver.readthedocs.io/en/latest/prepare-your-data/
################################################################

module load gcc/6.3.0 vcftools/0.1.16 plink/1.90b6.7 bcftools/1.15.1

################################
### Download tools and sites ###
################################

cd /zfs1/User/tools

wget http://www.well.ox.ac.uk/~wrayner/tools/HRC-1000G-check-bim-v4.2.7.zip
wget ftp://ngs.sanger.ac.uk/production/hrc/HRC.r1-1/HRC.r1-1.GRCh37.wgs.mac5.sites.tab.gz

gzip -d HRC.r1-1.GRCh37.wgs.mac5.sites.tab.gz

###############################################################
### Convert vcf or ped/map to bed & Create a frequency file ###
###############################################################

### cohort
# cd /zfs1/User/cohort

vcftools --vcf cohort_raw.vcf --out cohort_raw --plink
plink --bfile cohort_raw --freq --make-bed --out cohort_raw

###########################################
### Execute pre-imputation check script ###
###########################################

# V4.3 version (the most up-to-date: chromosome X included)
perl ../tools/HRC-1000G-check-bim-v4.3.0/HRC-1000G-check-bim.pl -b cohort_raw.bim -f cohort_raw.frq -r ../tools/HRC.r1-1.GRCh37.wgs.mac5.sites.tab -h

sh Run-plink.sh

##################################
### Create sorted vcf.gz files ###
##################################

mkdir -p ./impu_prep
for chrom in $(seq 1 23); do

    input_file="cohort_raw-updated-chr${chrom}.vcf"
    output_file="${input_file}.gz"

    # sort and compress VCF
    bcftools sort "${input_file}" -Oz -o ./impu_prep/"${output_file}"
    # create index file
    bcftools index -t ./impu_prep/"${output_file}"

    echo "Sorting or compressing for ${input_file} finished."

done
